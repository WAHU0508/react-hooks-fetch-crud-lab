export const data = [
  {
    id: 1,
    prompt: "lorem testum 1",
    answers: ["choice 1", "choice 2", "choice 3", "choice 4"],
    correctIndex: 0,
  },
  {
    id: 2,
    prompt: "lorem testum 2",
    answers: ["choice 1", "choice 2", "choice 3", "choice 4"],
    correctIndex: 2,
  },
];
